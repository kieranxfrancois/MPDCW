package org.me.gcu.mpd_cw;
public class WidgetClass
{
    private String title;
    private String description;
    private String link;
    private String pubDate;

    public WidgetClass()
    {
        title = "";
        description = "";
        link = "";
        pubDate = "";
    }

    public WidgetClass(String abolt,String awasher,String anut, String apubDate)
    {
        title = abolt;
        description = awasher;
        link = anut;
        pubDate = apubDate;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String atitle)
    {
        title = atitle;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String adescription)
    {
        description = adescription;
    }

    public String getLink()
    {
        return link;
    }

    public void setLink(String alink)
    {
        link = alink;
    }

    public String getPubDate()
    {
        return pubDate;
    }

    public void setPubDate(String apubDate)
    {
        link = apubDate;
    }

    public String toString()
    {
        String temp;

        temp = title + " " + description + " " + link + " " + pubDate;

        return temp;
    }

} // End of class
